package com.p1;

public class MainApp {

	public static void main(String[] args) {
		Circle c=new Circle();
		System.out.println(c.area());
		Triangle t=new Triangle();
		System.out.println(t.area());

	}
}
