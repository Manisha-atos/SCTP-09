package com.p1;

public interface calculation {
double add(double x,double y);
}
