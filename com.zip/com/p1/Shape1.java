package com.p1;
//public ,constants,abstract 
public interface Shape1 {
double pi=3.14;// variable constants
double area(); //method declaration
}
