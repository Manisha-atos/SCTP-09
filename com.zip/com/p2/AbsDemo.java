package com.p2;
abstract class Shape1 {
void show(String x)
{
	System.out.println("Hello from "+x);
}
abstract double area();
}
class Circle extends Shape1
{

	@Override
	double area() {
		// TODO Auto-generated method stub
		return Math.PI*2.3*2.3;
	}
	
}
class AbsDemo
{
	public static void main(String ar[])
	{
		Circle c=new Circle();
		System.out.println(c.area());
	}
}