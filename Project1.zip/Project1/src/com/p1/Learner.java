package com.p1;

import java.util.Scanner;

public class Learner {
	//instance variable,propeties,attributes
int lid;
String name;
int age;
Scanner sc=new Scanner(System.in);
//methods, behaviours
void getData()
{
	//local variable
	String city="Singapore";
	System.out.println("Enter Learner details");
	lid=sc.nextInt();
	name=sc.next();
	age=sc.nextInt();
		
}
void display()
{
	System.out.println(lid);
	System.out.println(name);
	System.out.println(age);
	//System.out.println(city);
}
public static void main(String ar[])
{
	Learner l1=new Learner();
	l1.getData();
	l1.display();
	Learner l2=new Learner();
	l2.getData();
	l2.display();
	
}
	

}
