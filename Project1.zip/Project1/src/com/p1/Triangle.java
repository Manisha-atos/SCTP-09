package com.p1;

public class Triangle  implements Shape1 {

	@Override
	public double area() {
		double l,b;
		l=1.2;b=4.5;
		double a=0.5*l*b;				
		return a;
	}

}
