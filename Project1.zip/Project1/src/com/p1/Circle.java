package com.p1;

public class Circle implements Shape1,calculation{
	//default access specifier
	//defination of area function from Shape1 interface , public 
	public double area()
	{
		double r=2.2;
		double a=Shape1.pi*r*r;
		return a;
	}

	@Override
	public double add(double x, double y) {
		// TODO Auto-generated method stub
		return 0;
	}

}
