package com.p1;

import java.util.Scanner;

class Box
{
	double w,h,d;
	Scanner sc=new Scanner(System.in);
	void getData() 
	{
		System.out.println("enter w,h,d of a Box");
		w=sc.nextDouble();
		h=sc.nextDouble();
		d=sc.nextDouble();
	}
	 void volume()
	{
		System.out.println("Calculate volume of a box");
		double vol=w*h*d;
		System.out.println("Volume of a box ="+vol);
	}
}

public class BoxDemo {

	public static void main(String[] args) {
		Box mb=new Box();// object ClassName objectname=new ClassName();
		mb.getData();
		mb.volume();
		Box wb=new Box();
		wb.getData();
		wb.volume();

	}

}
