package com.p2;

public class Test2 {
public String name="Manisha";
}
