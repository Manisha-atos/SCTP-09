package com.p4;

import java.util.Scanner;
public class Test1 {

	public static void main(String[] args) {
		int x,y;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 2 nos");
		x=sc.nextInt();
		y=sc.nextInt();// second can be zero unchecked
//		x=y;
//		y=x;
	 System.out.println("x="+x);//200
	 System.out.println("y="+y);//100
	 System.out.println("Addition="+(x+y));
	 try
	 {
	 System.out.println("Division="+x/y);
	 }
	 catch(Exception e)
	 {
		 System.out.println(e);
	 }
	 System.out.println("Subtraction="+(x-y));
	 System.out.println("Multiplication ="+(x*y));
	}

}
