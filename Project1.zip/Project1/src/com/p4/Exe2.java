package com.p4;

import java.util.Scanner;

public class Exe2 {

	public static void main(String[] args) {
		int x,y;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter 2 nos");
		x=0;
		y=0;
		try
		{
		x=sc.nextInt();//x=one
		y=sc.nextInt();
		}
		catch(Exception e)
		{
			System.out.println("I am inside first Try "+e);
		}
		try
		{
		System.out.println(x/y);//0/0
		}
		catch(Exception e)
		{
			System.out.println("I am in second try"+e);
		}
		System.err.println("End of my application ");
	}

}
