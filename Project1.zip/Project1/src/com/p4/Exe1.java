package com.p4;
import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;
public class Exe1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a,b;
		try
		{
		System.out.println("Enter 2 nos");
		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println(a/b);
		}
		catch(ArithmeticException e)
		{
			System.out.println("2nd number can not zero");
			System.out.println(e);
		}
		/*catch(InputMismatchException e)
		{
			System.out.println("Input is not correct format");
		}*/
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("End of my application");
		
	}
}
