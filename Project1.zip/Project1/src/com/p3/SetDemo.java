package com.p3;
import java.util.*;

public class SetDemo {
	public static void main(String ar[])
	{
	// unordered collection 
	//wont take the duplicate values 
	Set s=new HashSet();
	s.add("Apple");
	s.add(3.14);
	s.add(100);
	s.add("apple");
	s.add(300);
	s.add("Apple");
	System.out.println(s);
	System.out.println(s.size());
	System.out.println(s.contains("Mango"));
	System.out.println(s.isEmpty());
	s.remove("Apple");
	System.out.println(s);
	s.clear();
	
	System.out.println(s.isEmpty());
	
	
	}

}
