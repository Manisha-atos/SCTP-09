package com.p3;
import java.util.*;
import java.util.Map.Entry;
public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map m=new HashMap();
		m.put(1,"Apple");
		m.put(12, "Mango");
		m.put(33, "Banana");
		m.put(10, "Orange");
		System.out.println(m);
		//iteration in a Map 
		Set s=m.entrySet();
		System.out.println(s);
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry e=(Entry) i.next();		
			System.out.println(e.getKey());
			System.out.println(e.getValue());
		}	

	}

}
