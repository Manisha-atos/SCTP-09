package com.p3;

public class Test1 {
	int x;//instance vari default
	private  int y=200;
	void show() //method  default accessible with in the same package
	{
		x=100;
		System.out.println(x);
		System.out.println(y);
	}	

}
