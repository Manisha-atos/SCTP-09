package com.p3;

class Student
{
	int sid;
	String sname;
	int age;
	Student(int a,String b,int c)// constructor is to initialize the object 
	{
		System.out.println("Default constr called");
		sid=a;
		sname=b;
		age=c;
		
	}
	void display()
	{
		System.out.println(sid);//0
		System.out.println(sname);//null
		System.out.println(age);//0
	}
}

public class ConstructorDemo {

	public static void main(String[] args) {
		Student s1=new Student(101,"MAnisha",33);  //con executed
		s1.display();
		Student s2=new Student(102,"Neal",11);
		s2.display();

	}

}
