package com.p3;
class Bank
{
int withdraw(int amt,int wamt)
	{
		return amt-wamt;
	}
}
public class BankDemo {

	public static void main(String[] args) {
		Bank b1=new Bank();
		int res=b1.withdraw(3000,2000);
		System.out.println("Inside the Bank Application ");
		System.out.println("Your available balance post withdraw is "+res);

	}

}
