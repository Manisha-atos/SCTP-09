package com.p3;
import java.util.*;
public class SorteSetDemo {
	public static void main(String[] args) {
		SortedSet s=new TreeSet();
		s.add("apple");
		s.add("Mango");
		s.add("orange");
		s.add("mango");
		s.add("banana");
		System.out.println(s);
		s.add("3.14");//s.add(3.14)  Double--String not possible
		System.out.println(s);
		for (Object x:s)
		{
			System.out.println(x);
		}
		
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}

		
	}

}
