package com.p3;
import java.util.*;
public class ListDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List <String>l1=new LinkedList();
l1.add("Apple");
l1.add("Mango");
l1.add("Apple");
l1.add("Banana");
System.out.println(l1.indexOf("Apple"));
System.out.println(l1.lastIndexOf("Apple"));

System.out.println(l1);
for (String  x:l1)
	System.out.println(x);

	}



}
