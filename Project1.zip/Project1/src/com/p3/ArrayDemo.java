package com.p3;

public class ArrayDemo {

	public static void main(String[] args) {
		int a[]=new int[5];//grp of 5 integer values
		a[0]=11;
		a[1]=221;
		a[2]=23;
		a[3]=4;
		a[4]=5;
		
		//a[5]=300; error out of bounds as the array is of fix size
		System.out.println(a[0]);
				
		
	}

}
