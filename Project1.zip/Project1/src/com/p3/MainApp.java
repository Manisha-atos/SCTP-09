package com.p3;

import com.p2.Test2;

public class MainApp {

	public static void main(String[] args) {
		Test1 t1=new Test1();
		t1.show();
		t1.x=30000;
		System.out.println(t1.x);
		//t1.y=40000;
		//System.out.println(t1.y);
		Test2 t2=new Test2();
		System.out.println(t2.name);

	}

}
