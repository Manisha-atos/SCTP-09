package com.p3;
import java.util.*;
public class ListDemo {

	public static void main(String[] args) {
		//ordered collection in order object insertion , accepted duplicates 
		List l=new ArrayList();
		l.add("apple");
		l.add(100);
		l.addFirst("Core Java");
		l.addLast("ReactJS");
		l.add("apple");
		l.add(3000);
		l.add("Manisha");		
		System.out.println(l);
		l.remove("apple");
		System.out.println(l);
		l.add(3,"Oracle");
		System.out.println(l);
		//l.remove(2);
		System.out.println(l);
		System.out.println(l.getFirst());
		System.out.println(l.getLast());
		System.out.println(l.indexOf("ReactJS"));
	
		
	
		

	}

}
