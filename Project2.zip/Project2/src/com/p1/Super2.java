package com.p1;
class Par
{
	int x=10;
	void show()
	{
		System.out.println("class Par"+x);
	}
}
class Child extends Par
{
	int y=20;
	int x=30;
	void show()
	{
		super.show();
		System.out.println("class Child"+y);
		System.out.println(x);
		System.out.println(super.x);
	}
}
public class Super2 {

	public static void main(String[] args) {
		Child obj=new Child();
		obj.show();

	}

}
