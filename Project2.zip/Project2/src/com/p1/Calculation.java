package com.p1;

public class Calculation {	
	void add()
	{
		System.out.println("Add method without arguments");
	}
	void add(int x,int y)
	{
		int res=x+y;
		System.out.println("Addition of 2 integers"+res);
	}
void add(int x,float y)
{
	float res=x+y;
	System.out.println(res);
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculation c=new Calculation();
		c.add(2,3.3f);
		c.add();
		c.add(1,2);

	}

}
