package com.p1;
class A  //GP
{
	int x=100;
	void showA()
	{
		System.out.println("class A"+x);
	}
}
class B extends A //P
{
	int y=200;
	void showB()
	{
		System.out.println("class B"+y);
	}
}
class C extends B //child
{
	int z=300;
	void showC()
	{
		System.out.println(z);
	}
}
public class SimpleInhertance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C obj=new C();
		obj.showA();
		obj.showB();
		obj.showC();

	}

}
