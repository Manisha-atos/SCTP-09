package com.p1;
class Box
{
	double w,h,d;
	//default
	Box()
	{
		w=h=d=1.2;
	}
	//parameterized 
	Box(double x)
	{
		w=h=d=x;
	}
	Box (double w,double h,double d)
	{
		this.w=w;
		this.h=h;
		this.d=d;				
	}
	double volume()
	{
		return w*h*d;
	}
}

public class BoxDemo {

	public static void main(String[] args) {
		Box b1=new Box();
		System.out.println(b1.volume());
		Box b2=new Box(3.3);
		System.out.println(b2.volume());
		Box b3=new Box(1.1,2.2,3.3);
		System.out.println(b3.volume());

	}

}
