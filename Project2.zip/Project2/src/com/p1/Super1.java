package com.p1;
class A2
{
	A2(int x)
	{
		System.out.println("class A "+x);
	}
}
class B2 extends A2
{
	B2(double x)
	{
		super(1000);
		
		System.out.println("class B "+x);
	}
}
public class Super1 {

	public static void main(String[] args) {
		B2 obj =new B2(3.3);
		

	}

}
