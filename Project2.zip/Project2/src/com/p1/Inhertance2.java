package com.p1;
class A1  //GP
{
	int x=100;
	void showA()
	{
		System.out.println("class A"+x);
	}
}
class B1  extends A1 //P
{
	int y=200;
	void showB()
	{
		System.out.println("class B"+y);
	}
}
class C1 extends A1 //child
{
	int z=300;
	void showC()
	{
		System.out.println(z);
	}
}
public class Inhertance2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C1 obj=new C1();
		obj.showA();
		//obj.showB();
		obj.showC();

	}

}
