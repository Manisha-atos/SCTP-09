package com.p2;

import java.util.Scanner;



class Employee {
	
	int EmployeeId, Age, DeptId;
	String Name;
	
	Employee(int EmployeeId, String Name, int Age, int DeptId) {
		this.EmployeeId = EmployeeId;
		this.Name = Name;
		this.Age = Age;
		this.DeptId = DeptId;				
	}
	
	public void printEmployeeInfo() {
		System.out.println("Employee Id  : " + EmployeeId );
		System.out.println("Employee Name: " + Name );
		System.out.println("Employee Age : " + Age );
		System.out.println("Deptment Id  : " + DeptId );		
	}

}

class PermanentEmployee extends Employee {

	double Salary, Commission;
	
	PermanentEmployee(int EmployeeId, String Name, int Age, int DeptId) {
		super(EmployeeId, Name, Age, DeptId);
	}
	
	public void setSalary(double Salary, double Commission) {
		this.Salary = Salary;
		this.Commission = Commission;		
	}

	public void printEmployeeInfo() {
		double TotalSalary = Salary + Commission;
		super.printEmployeeInfo();
		System.out.println("Total salary for " + Name + " is: " + TotalSalary );
	}
}
class ContractEmployee extends Employee {

	double HourlyRate;
	int NumHours;
	
	ContractEmployee(int EmployeeId, String Name, int Age, int DeptId) {
		super(EmployeeId, Name, Age, DeptId);
	}
	
	public void setSalary(double HourlyRate, int NumHours) {
		this.HourlyRate = HourlyRate;				
		this.NumHours = NumHours;
	}

	public void printEmployeeInfo() {
		double TotalSalary = HourlyRate * NumHours;
		super.printEmployeeInfo();
		System.out.println("Total salary for " + Name + " is: " + TotalSalary );
	}
	
}

public class Inheritance3 {

	public static void main(String[] args) {
		System.out.println("Generate Employee  salary");
		System.out.println("1-- generate salary for PEMP");
		System.out.println("2-- generate salary for CEMP");
		System.out.println("Enter your choice [1-2]");
		int ch;
		Scanner sc=new Scanner(System.in);
		ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			PermanentEmployee p1=new PermanentEmployee(101, "Kelvin", 33, 10);
			p1.setSalary(3000,2000);
			p1.printEmployeeInfo();
			break;
		case 2:
			ContractEmployee c1=new ContractEmployee(102,"Manisha",33,20);
			c1.setSalary(50, 24);
			c1.printEmployeeInfo();
			break;
		default:
			System.out.println("Invalid choice");
		}

			

	}

}
